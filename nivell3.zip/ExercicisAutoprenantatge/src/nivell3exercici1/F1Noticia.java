package nivell3exercici1;

public class F1Noticia extends Noticia {

	//FIELDS
	private String escuderia;
	
	//CONSTRUCTOR
	public F1Noticia(String titular, String escuderia) {
		super(titular);
		this.escuderia = escuderia;
	}

	//METHODS
	public float calcularPreuNoticia() {
		float preu = 100;
			
		if (escuderia == "Ferrari" || escuderia == "Mercedes" ) {
			preu = preu + 50;	
		}
		return preu;		
	}
	public float calcularPuntuacio() {
		float puntuacio = 4;
		if (escuderia == "Ferrari" || escuderia == "Mercedes" ) {
			puntuacio = puntuacio + 2;	
		}
		return puntuacio;		
	}
	
	@Override
	public String toString() {
		return " - [ Noticia " + getTitular()+ ", escuderia = " + escuderia + ", text = " +
				getText() + ", puntuació = " + getPuntuacio() + ", preu = "
				+ getPreu() + "]";
	}
}
