package nivell3exercici1;

public abstract class Noticia {

	//FIELDS
	private String titular;
	private String text;
	private float puntuacio;
	private float preu;
	
	//CONSTRUCTOR
	public Noticia(String titular) {
		this.titular = titular;
		this.text = "";
		this.puntuacio = 0;
		this.preu = 0;
	}

	//GETTERS AND SETTERS
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public float getPuntuacio() {
		return puntuacio;
	}
	public void setPuntuacio(float puntuacio) {
		this.puntuacio = puntuacio;
	}
	public float getPreu() {
		return preu;
	}
	public void setPreu(float preu) {
		this.preu = preu;
	}
	
	//METHODS
	public abstract float calcularPreuNoticia();
	public abstract float calcularPuntuacio();
	public abstract String toString();
}
