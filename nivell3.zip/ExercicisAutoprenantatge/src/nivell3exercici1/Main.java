package nivell3exercici1;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	//PERQ AQUI? 
    static Scanner scanner = new Scanner(System.in);
    static ArrayList<Redactor> listaDeRedactores = new ArrayList<>();

	public static void main(String[] args) {
		int respuesta;
	    do {
	    	mostrarMenu();
	    	System.out.print("\nIntroduce la opción deseada: ");
	    	respuesta = scanner.nextInt();
	        scanner.nextLine();  // Consumir la nueva línea después de leer el número

            switch (respuesta) {
                case 1:
                    introducirRedactor();
                    break;
                case 2:
                    eliminarRedactor();
                    break;
                case 3:
                    introducirNoticia();
                    break;
                case 4:
                    eliminarNoticia();
                    break;
                case 5:
                    mostrarNoticiasPorRedactor();
                    break;
                case 6:
                    calcularPuntuacionNoticia();
                    break;
                case 7:
                    calcularPrecioNoticia();
                    break;
                case 0:
                    System.out.println("Saliendo del programa. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        } while (respuesta != 0);
	}
	
	//METHODS
    private static void mostrarMenu() {
        System.out.println("\nMenú:");
        System.out.println("1.- Introducir redactor.");
        System.out.println("2.- Eliminar redactor.");
        System.out.println("3.- Introducir noticia a un redactor.");
        System.out.println("4.- Eliminar noticia (ha de demanar redactor i titular de la notícia).");
        System.out.println("5.- Mostrar todas las noticias por redactor.");
        System.out.println("6.- Calcular puntuación de la noticia.");
        System.out.println("7.- Calcular precio-noticia.");
        System.out.println("0.- Salir.");
    }

    private static void introducirRedactor() {
        System.out.print("Introduce el nombre del redactor: ");
        String nombreRedactor = scanner.nextLine();
        System.out.print("Introduce el dni del redactor: ");
        String dniRedactor = scanner.nextLine();
        Redactor redactor = new Redactor(nombreRedactor,dniRedactor );
        listaDeRedactores.add(redactor);
        System.out.println("Redactor '" + nombreRedactor + "' introducido correctamente.");
    }

    private static void eliminarRedactor() {
        System.out.print("Introduce el nombre del redactor a eliminar: ");
        String nombreRedactor = scanner.nextLine();
        listaDeRedactores.remove(buscarRedactor(nombreRedactor));
        System.out.println("Redactor '" + nombreRedactor + "' eliminado correctamente.");
    }

    private static Redactor buscarRedactor(String nombre) {
        for (Redactor redactor : listaDeRedactores) {
            if (redactor.getNombre().equals(nombre)) {
                return redactor; // Redactor encontrado
            }
        }
        return null; // Redactor no encontrado
    }
	    
    private static void introducirNoticia() {
        System.out.print("Introduce el nombre del redactor: ");
        String nombreRedactor = scanner.nextLine();
        Redactor redactor = buscarRedactor(nombreRedactor);
        if (listaDeRedactores.contains(redactor) == true) {

        	System.out.println("Selecciona el tipo de noticia: \n1. Fútbol \n2. Baloncesto \n3. F1 \n4. Motociclismo "
        			+ "\n5. Tenis \n6. Motociclismo");
            int tipoNoticia = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea después de leer el número

            System.out.print("Ingrese el titular de la noticia: ");
            String titular = scanner.nextLine();

            switch (tipoNoticia) {
                case 1:
                    introducirNoticiaFutbol(redactor, titular);
                    break;
                case 2:
                    introducirNoticiaBasquet(redactor, titular);
                    break;
                case 3:
                    introducirNoticiaF1(redactor, titular);
                    break;    
                case 4:
                    introducirNoticiaMotociclismo(redactor, titular);
                    break;
                case 5:
                    introducirNoticiaTenis(redactor, titular);
                    break;
                default:
                    System.out.println("Tipo de noticia no válido.");
            }
        }
    }

    //PREGUNTAS NOTICIA
    private static String preguntarCompeticion(){
    	System.out.print("Ingrese la competición: ");
        String competicion = scanner.nextLine();
		return competicion;
    }  
    private static String preguntarClub(){
    	System.out.print("Ingrese el club/equipo: ");
        String club = scanner.nextLine();
		return club;
    }   
    private static String preguntarJugador(){
    	System.out.print("Ingrese el jugador: ");
        String jugador = scanner.nextLine();
		return jugador;
    }
    private static String preguntarEscuderia() {
    	System.out.print("Ingrese nombre de escuderia: ");
        String jugador = scanner.nextLine();
		return jugador;
    }
  
    //INTRODUCIR NOTICIAS
    private static void introducirNoticiaFutbol(Redactor redactor, String titular) {
        FutbolNoticia noticiaFutbol = new FutbolNoticia(titular, preguntarCompeticion(), preguntarClub(), preguntarJugador());
        redactor.getNoticias().add(noticiaFutbol);
        System.out.println("Noticia de agregada correctamente.");
    }        
    private static void introducirNoticiaBasquet(Redactor redactor, String titular) {
        BasquetNoticia noticiaBasquet = new BasquetNoticia(titular, preguntarCompeticion(),preguntarClub());
        redactor.getNoticias().add(noticiaBasquet);
        System.out.println("Noticia agregada correctamente.");
    }
    private static void introducirNoticiaF1(Redactor redactor, String titular) {
        F1Noticia noticiaF1 = new F1Noticia(titular, preguntarEscuderia());
        redactor.getNoticias().add(noticiaF1);
        System.out.println("Noticia agregada correctamente.");
    }  
    private static void introducirNoticiaMotociclismo(Redactor redactor, String titular) {
        MotociclismeNoticia noticiaMoto = new MotociclismeNoticia(titular, preguntarClub());
        redactor.getNoticias().add(noticiaMoto);
        System.out.println("Noticia agregada correctamente.");
    }    
    private static void introducirNoticiaTenis(Redactor redactor, String titular) {
        TenisNoticia noticiaTenis = new TenisNoticia(titular, preguntarCompeticion(), preguntarJugador());
        redactor.getNoticias().add(noticiaTenis);
        System.out.println("Noticia agregada correctamente.");
    }
    

    //ELIMINAR NOTICIAS
    private static void eliminarNoticia() {
        System.out.print("Introduce el nombre del redactor: ");
        String nombreRedactor = scanner.nextLine();
        
        Redactor redactor = buscarRedactor(nombreRedactor);
        if (listaDeRedactores.contains(redactor)) {
            System.out.print("Introduce el titular de la noticia a eliminar: ");
            String titular = scanner.nextLine();
            Noticia noticia = buscarNoticia( redactor, titular);
            redactor.getNoticias().remove(noticia);
            System.out.println("Noticia '" + titular + "' eliminada correctamente para el redactor '" + nombreRedactor + "'.");
        } else {
            System.out.println("El redactor '" + nombreRedactor + "' no existe.");
        }
    }
    
    private static Noticia buscarNoticia(Redactor redactor, String titular) {
    	Noticia noticiaEncontrada = null;
         for (Noticia noticiaRedactor : redactor.getNoticias()) {
             if (noticiaRedactor.getTitular().equalsIgnoreCase(titular)) {
                 System.out.println("Noticia encontrada:");
                 System.out.println("Titular: " + noticiaRedactor.getTitular());
                 noticiaEncontrada = noticiaRedactor; 
             }
         }
		return noticiaEncontrada;
    }

    private static void mostrarNoticiasPorRedactor() {
        System.out.print("Introduce el nombre del redactor: ");
        String nombreRedactor = scanner.nextLine();
        Redactor redactor = buscarRedactor(nombreRedactor);
        if (listaDeRedactores.contains(redactor)) {
            System.out.println("Noticias de '" + nombreRedactor + "':");
            System.out.println( redactor.getNoticias().toString());
            
            for (Noticia noticia : redactor.getNoticias()) {
                System.out.println("\n- " + noticia.toString());
            }
        } else {
            System.out.println("El redactor '" + nombreRedactor + "' no existe.");
        }
    }
	
	private static void calcularPuntuacionNoticia() {
		System.out.print("Introduce el nombre del redactor: ");
        String nombreRedactor = scanner.nextLine();
        Redactor redactor = buscarRedactor(nombreRedactor);
        if (listaDeRedactores.contains(redactor) == true) {
            System.out.print("Introduce el titular de la noticia: ");
            String titular = scanner.nextLine();
            Noticia noticia = buscarNoticia(redactor, titular);
            System.out.println("\nPuntuación de esta noticia: " + noticia.getPuntuacio());
        }
	}
	
	private static void calcularPrecioNoticia() {
		System.out.print("Introduce el nombre del redactor: ");
        String nombreRedactor = scanner.nextLine();
        Redactor redactor = buscarRedactor(nombreRedactor);
        if (listaDeRedactores.contains(redactor) == true) {
            System.out.print("Introduce el titular de la noticia: ");
            String titular = scanner.nextLine();
            Noticia noticia = buscarNoticia(redactor, titular);
            System.out.println("\nEl precio de esta noticia: " + noticia.getPreu() + "€");
        }
	}
	   
	

}
