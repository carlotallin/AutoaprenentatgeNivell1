package nivell3exercici1;

import java.util.ArrayList;

public class Redactor {

	//FIELDS
	private String nom;
	private final String dni;
	private static float sueldo = 1500; //Sueldo inicial
    private ArrayList<Noticia> noticias;

	
	//CONSTRUCTOR
	public Redactor(String nom, String dni) {
		this.nom = nom;
		this.dni = dni;
        this.noticias = new ArrayList<>();

	}

	//GETTERS AND SETTERS
	public String getDni() {
		return dni;
	}
	public String getNombre() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public static float getSou() {
		return sueldo;
	}
	public static void setSou(float sou) {
		Redactor.sueldo = sou;
	}
	public ArrayList<Noticia> getNoticias() {
		return noticias;
	}
	

}
