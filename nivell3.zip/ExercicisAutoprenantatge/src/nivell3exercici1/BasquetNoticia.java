package nivell3exercici1;

public class BasquetNoticia extends Noticia {

	//FIELDS
	private String competicio;
	private String club;
	
	//CONSTRUCTOR
	public BasquetNoticia(String titular, String competicio, String club) {
		super(titular);
		setPreu(calcularPreuNoticia());
		this.club = club;
		this.competicio = competicio;
	}

	//GETTERS AND SETTERS
	public String getCompeticio() {
		return competicio;
	}

	public void setCompeticio(String competicio) {
		this.competicio = competicio;
	}

	public String getClub() {
		return club;
	}

	public void setClub(String club) {
		this.club = club;
	}
	
	//METHODS
	public float calcularPreuNoticia() {
		float preu = 250;		
		if (club == "Barça" || club == "Madrid" ) {
			preu = preu + 75;	
		}		
		if (competicio == "Eurolliga") {
			preu = preu + 75;
		}			
		return preu;	
	}
	
	public float calcularPuntuacio() {
		float puntuacio = 4;
		if (club == "Barça" || club == "Madrid" ) {
			puntuacio = puntuacio + 1;	
		}		
		if (competicio == "Eurolliga") {
			puntuacio = puntuacio + 3;
		}	
		if ((getTitular().contains("ABC"))== true) {
			puntuacio = puntuacio + 3;
		}	
		return puntuacio;	
	}

	@Override
	public String toString() {
		return " - [ Noticia " + getTitular()+ ", club=" + club + ", competició()="
				+ competicio + ", text = " + getText() + ", puntuació = " + getPuntuacio() + ", preu = "
				+ getPreu() + "]";
	}

}
