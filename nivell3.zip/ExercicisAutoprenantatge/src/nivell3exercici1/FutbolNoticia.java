package nivell3exercici1;

public class FutbolNoticia extends Noticia {

	//FIELDS
	private String competicio;
	private String club;
	private String jugador;
	
	//CONSTRUCTOR
	public FutbolNoticia(String titular, String competicio, String club, String jugador) {
		super(titular);
		setPuntuacio(calcularPuntuacio());
		setPreu(calcularPreuNoticia());
		this.club = club;
		this.competicio = competicio;
		this.jugador = jugador;
	}

	//METHODS
	@Override
	public float calcularPreuNoticia() {
		float preu = 300;
		
		if (club == "Barça" || club == "Madrid" ) {
			preu = preu + 100;	
		}		
		if (competicio == "Lliga de Campions") {
			preu = preu + 100;
		}				
		if (jugador == "Ferran Torres"|| jugador == "Benzema") {
			preu = preu + 50;
		}			
		return preu;	
	}

	@Override
	public float calcularPuntuacio() {
		float puntuacio = 5;
		
		if (club == "Barça" || club == "Madrid" ) {
			puntuacio = puntuacio + 1;	
		}		
		if ( competicio == "Lliga" ) {
			puntuacio = puntuacio + 2;
		}	
		if (competicio == "Lliga de Campions") {
			puntuacio = puntuacio + 3;
		}			
		if (jugador == "Ferran Torres"|| jugador == "Benzema") {
			puntuacio = puntuacio + 1;
		}			
		return puntuacio;	
	}

	@Override
	public String toString() {
		return " - [Noticia=" + competicio + ", club=" + club + ", jugador=" + jugador + ", getTitular()="
				+ getTitular() + ", getText()=" + getText() + ", getPuntuacio()=" + getPuntuacio() + ", getPreu()="
				+ getPreu() + "]";
	}
		
}
