package nivell3exercici1;

public class TenisNoticia extends Noticia{
		
		//FIELDS
		private String competicio;
		private String tenista;
		
		//CONSTRUCTOR
		public TenisNoticia(String titular, String competicio, String tenista) {
			super(titular);
			this.competicio = competicio;
			this.tenista = tenista;
		}
	
		//METHODS
		public float calcularPreuNoticia() {
			float preu = 150;				
			if (tenista == "Federer"|| tenista == "Nadal" || tenista == "Djokovic") {
				preu = preu + 100;
			}			
			return preu;	
		}
		public float calcularPuntuacio() {
			float puntuacio = 4;				
			if (tenista == "Federer"|| tenista == "Nadal" || tenista == "Djokovic") {
				puntuacio = puntuacio + 3;
			}			
			return puntuacio;	
		}

		@Override
		public String toString() {
			return " - [ Noticia " + getTitular()+ ", tenista = " + tenista + ", competició()="
					+ competicio + ", text = " + getText() + ", puntuació = " + getPuntuacio() + ", preu = "
					+ getPreu() + "]";
		}
}
