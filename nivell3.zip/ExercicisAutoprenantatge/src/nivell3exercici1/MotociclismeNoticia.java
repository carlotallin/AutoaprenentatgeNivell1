package nivell3exercici1;

public class MotociclismeNoticia extends Noticia{

	//FIELDS
	private String equip;
	
	//CONSTRUCTOR
	public MotociclismeNoticia(String titular, String equip) {
		super(titular);
		setPreu(calcularPreuNoticia());
		setPuntuacio(calcularPuntuacio());
		this.equip = equip;
	}

	//METHODS
	public float calcularPreuNoticia() {
		float preu = 100;
		if (equip == "Honda" || equip == "Yamaha" ) {
			preu = preu + 50;	
		}
		return preu;		
	}
	public float calcularPuntuacio() {
		float puntuacio = 3;
		if (equip == "Honda" || equip == "Yamaha" ) {
			puntuacio = puntuacio + 3;	
		}
		return puntuacio;		
	}
	
	@Override
	public String toString() {
		return " - [ Noticia " + getTitular()+ ", equip = " + equip + ", text = " + getText() + 
				", puntuació = " + getPuntuacio() + ", preu = "
				+ getPreu() + "]";
	}
}
