package nivell1exercici1;

public abstract class Instrument {

	//Fields
	private String name;
	private double price;
	
	// Bloque de inicialización
    {
        System.out.println("Bloque de inicialización: Se ejecuta al crear una instancia de Instrument.");
    }

    // Bloque estático
    static {
        System.out.println("Bloque estático: Se ejecuta cuando la clase Instrument se carga en memoria.");
    }

	//Constructor
	public Instrument( String name, double price) {
		this.setName(name);
		this.setPrice(price);
	}
	

	public abstract void play();


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	
}
