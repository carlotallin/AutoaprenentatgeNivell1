package nivell1exercici1;

public class PercussionInstrument extends Instrument {

	public PercussionInstrument(String name, float price) {
		super(name, price);
	}

	@Override
	public void play() {
		System.out.println("Està sonant un instrument de percussió");
	}
	
}
