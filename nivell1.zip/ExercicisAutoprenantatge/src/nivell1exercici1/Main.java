package nivell1exercici1;

public class Main {

	public static void main(String[] args) {
        // Creación de la primera instancia de InstrumentoDeViento
		AirInstrument  instrument1 = new AirInstrument("flauta", 12);
		// Acceso a un miembro estático de la clase InstrumentoDeCuerda
        System.out.println(StringInstrument.class.getName());
		
	}

}
