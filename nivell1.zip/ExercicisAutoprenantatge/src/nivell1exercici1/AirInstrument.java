package nivell1exercici1;

public class AirInstrument extends Instrument {


	public AirInstrument(String name, float price) {
		super(name, price);
	}
 
	@Override
	public void play() {
		System.out.println("Està sonant un instrument de vent");
	}
	
	
}
