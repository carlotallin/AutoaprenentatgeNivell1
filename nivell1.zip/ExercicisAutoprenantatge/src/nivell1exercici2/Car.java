package nivell1exercici2;

public class Car {

	private static final String brand = "BRANDX";
	private static String model = "MODEL1";
	private final  int potency;

	public Car(int potency) {
		this.potency = potency;
	}
	
	public static String getModel() {
		return model;
	}
	public int getPotency() {
		return potency;
	}
	public static String getBrand() {
		return brand;
	}
	public static void setModel(String model) {
		Car.model = model;
	}
	
	public static void stop() {
		System.out.println("El vehicle està accelerant");
	}

	public void run() {
		System.out.println("El vehicle està frenat");
	}
}
