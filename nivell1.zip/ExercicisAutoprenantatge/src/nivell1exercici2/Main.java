package nivell1exercici2;

public class Main {

	public static void main(String[] args) {
		
		// Acceso a los atributos desde la clase sin crear una instancia
        System.out.println("Brand: " + Car.getBrand());
        System.out.println("Model: " + Car.getModel());

        // Creación de una instancia de Cotxe y acceso al atributo POTENCIA
		Car car1 = new Car(1000);
        System.out.println("Potencia: " + car1.getPotency());
		car1.run();
		Car.stop();
	}
	
}
