package nivell2exercici1;

public class Main {

	public static void main(String[] args) {
		
		Smartphone phone = new Smartphone("marca","model");
		phone.alarma();
		phone.fotografiar();
	}

}
