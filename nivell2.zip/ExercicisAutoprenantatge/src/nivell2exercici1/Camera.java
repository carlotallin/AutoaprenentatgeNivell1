package nivell2exercici1;

public interface Camera {

	void fotografiar();
}
