package nivell2exercici1;

public interface Rellotge {
	void alarma();
}
